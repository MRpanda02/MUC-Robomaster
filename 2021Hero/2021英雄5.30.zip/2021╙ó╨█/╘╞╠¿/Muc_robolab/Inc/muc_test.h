#ifndef _MUC_TEST_H__
#define _MUC_TEST_H__
#include "main.h"

void TestLoop( int dTimes );


extern int16_t g_testNum1;
extern int16_t g_testNum2;
#endif  //_MUC_TEST_H__
