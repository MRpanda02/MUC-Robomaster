#include "muc_hardware_super_capacity.h"

