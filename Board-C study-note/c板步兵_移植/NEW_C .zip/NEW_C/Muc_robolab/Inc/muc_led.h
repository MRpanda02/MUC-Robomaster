#ifndef _MUC_LED_H__
#define _MUC_LED_H__

#include "muc_config_hardware.h"

void LedStaInit( void );
void LedTaskLoop( void );

#endif  //_MUC_LED_H__
