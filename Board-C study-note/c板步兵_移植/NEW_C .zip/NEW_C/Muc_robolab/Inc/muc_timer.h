#ifndef _MUC_TIMER_H__
#define _MUC_TIMER_H__

#include "muc_config_hardware.h"

void HandlerTim6CallBlack( void );

#endif  //_MUC_TIMER_H__
