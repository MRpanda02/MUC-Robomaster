#ifndef _MUC_HARDWARE_LED_H__
#define _MUC_HARDWARE_LED_H__

#include "muc_hardware_config.h"


void MucLedStaInit( void );
void Muc_LedStateUpdate( int sta );

#endif  // _MUC_HARDWARE_LED_H__
