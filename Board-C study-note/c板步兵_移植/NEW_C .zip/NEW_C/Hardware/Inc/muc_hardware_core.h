#ifndef _MUC_HARDWARE_CORE_H__
#define _MUC_HARDWARE_CORE_H__
#include "stm32f4xx_hal.h"

void MucSystemReboot( void );

#endif
