#include "muc_hardware_led.h"
#include "muc_ledIndicate.h"

//void Muc_LedRedOn( void )
//{
//		LED_Red_On();
//}
//void Muc_LedRedOff( void )
//{
//		LED_Red_Off();
//}
//void Muc_LedGreenOn( void )
//{
//		LED_Green_On();
//}
//void Muc_LedGreenOff( void )
//{
//		LED_Green_Off();
//}
//void Muc_LedRedToggle( void )
//{
//		LED_Red_Toggle();
//}
//void Muc_GreenRedToggle( void )
//{
//		LED_Green_Toggle();
//}

//void MucLedStaInit( void )
//{
//    LED_Red_On();
//    LED_Green_On();
//		Muc_LedIndicateRegisete( Muc_LedRedOn,Muc_LedRedOff,Muc_LedGreenOn,Muc_LedGreenOff,Muc_LedRedToggle,Muc_GreenRedToggle );
//}

